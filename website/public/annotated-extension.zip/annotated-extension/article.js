// Content script for any non-YouTube page. Wires the shared ArticlePage controller to extension messaging.
(() => {
  // Reloading the extension leaves an older copy of this script on the page with a dead connection. The newest
  // copy claims the page and the older one stays quiet, so the panel works again without reloading the page.
  // Take the older copy off the page before claiming it, so its button and its highlights go with it.
  const older = window.__annotatedArticle;
  if (older && older.page && typeof older.page.destroy === 'function') { try { older.page.destroy(); } catch { /* already gone */ } }
  // And anything a copy older than that left behind. Reloading the extension leaves the script that was
  // already on the page running with no way to reach the extension, and if it came from a version that could
  // not be asked to tidy up, its button stayed there. Two Annotate buttons, one of which did nothing.
  document.querySelectorAll('.annotated-ui').forEach((el) => el.remove());
  const mine = {};
  window.__annotatedArticle = mine;
  const orphaned = () => window.__annotatedArticle !== mine;
  const style = document.createElement('style');
  // The pens, with their colours written out. This sits on pages we do not own, so nothing here fades to
  // transparent, which would vanish on a dark page, and nothing uses a blend mode.
  // The panel sends the chosen colour with set-pen. These are the classic ones, used until it does.
  let INK = { hi: '#FFE14A', deep: '#F2C600', lift: '#FFEE9E', pending: '#FFF0A8' };
  let penName = 'chisel';
  const penCss = (name) => ArticleCore.penCss(name, INK);
  // The faint one while you are still dragging uses the browser's own highlight API, which takes a colour and
  // nothing else, so it stays flat whichever pen is chosen.
  // What would be taken if you captured now. A paler tint of the same yellow with the same ink, so it reads
  // as the pen resting rather than a second colour. The highlight API takes a colour and nothing else.
  const pendingCss = () => `::highlight(annotated-pending){background-color:${INK.pending};color:#1C2433}`;
  const paint = () => { style.textContent = penCss(penName) + pendingCss(); };
  paint();
  (document.head || document.documentElement).appendChild(style);
  // Talking to nobody means the extension has been reloaded or removed and this copy is a leftover, so it
  // takes itself off the page rather than leaving a button that cannot do anything.
  // A copy left behind by an extension reload throws "Extension context invalidated" at the call itself, before
  // there is any promise to catch, and Chrome listed that as an error of the extension. The call is guarded,
  // and a leftover takes itself off the page the first time it finds out.
  const retire = () => { try { if (mine.page) mine.page.destroy(); } catch { /* already gone */ } };
  const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch { return false; } };
  const send = (m) => {
    if (!alive()) return retire();
    try { chrome.runtime.sendMessage(m).catch(() => { if (!alive()) retire(); }); } catch { retire(); }
  };
  // Our own front page is told the extension is here, so it can drop the install steps. Nothing made in its
  // try-it is handed over: those are demonstrations, never published (David, 2026-09-24).
  if (location.origin === 'https://annotated-app.netlify.app') {
    document.documentElement.dataset.annotatedInstalled = '1';
    document.dispatchEvent(new CustomEvent('annotated-installed'));
    // Who the extension is signed in as, so our own site can offer the same account (recording of 2026-09-25 at
    // 03:54, where the extension, the site and Chrome were on three different accounts). Only the name, the email
    // and the id are handed over, never a token: sharing one session between two clients would have both
    // refreshing it, and Supabase revokes a session whose old refresh token comes back.
    const tellUser = (raw) => {
      let u = null;
      try { const s = typeof raw === 'string' ? JSON.parse(raw) : raw; u = s && s.user; } catch { u = null; }
      const d = document.documentElement.dataset, meta = (u && u.user_metadata) || {};
      if (u && u.id) { d.annotatedUserId = u.id; d.annotatedUserName = meta.full_name || meta.name || ''; d.annotatedUserEmail = u.email || ''; }
      else { delete d.annotatedUserId; delete d.annotatedUserName; delete d.annotatedUserEmail; }
      document.dispatchEvent(new CustomEvent('annotated-user'));
    };
    try {
      chrome.storage.local.get('annotated-auth').then((o) => tellUser(o['annotated-auth'])).catch(() => {});
      chrome.storage.onChanged.addListener((ch, a) => { if (a === 'local' && ch['annotated-auth']) tellUser(ch['annotated-auth'].newValue); });
    } catch { /* the extension went away */ }
  }
  // The Annotate button beside selected text can be turned off under Display.
  let pageButton = true;
  chrome.storage.local.get('annotatedPrefs').then((o) => { if (o.annotatedPrefs) pageButton = o.annotatedPrefs.pageButton !== false; }).catch(() => {});
  chrome.storage.onChanged.addListener((ch, a) => { if (a === 'local' && ch.annotatedPrefs) pageButton = (ch.annotatedPrefs.newValue || {}).pageButton !== false; });
  const page = ArticlePage.create({
    root: () => document.body,
    metaRoot: () => document,
    loc: () => location,
    send,
    scrollBy: (dy) => window.scrollBy({ top: dy, behavior: 'instant' }),
    viewport: () => ({ top: 0, bottom: window.innerHeight }),
    buttonEnabled: () => pageButton,
  });
  mine.page = page;
  // Podcasts: a page with an audio player can be clipped the same way as a video, as sound only.
  const pickAudio = () => {
    const list = [...document.querySelectorAll('audio')];
    return list.find((a) => isFinite(a.duration) && a.duration > 0) || list.find((a) => a.currentSrc || a.src || a.querySelector('source')) || null;
  };
  const metaContent = (sel) => { const m = document.querySelector(sel); return m ? (m.getAttribute('content') || '').trim() : ''; };
  const podMeta = () => ({
    url: location.href.split('#')[0],
    title: metaContent('meta[property="og:title"]') || (document.querySelector('h1') || {}).textContent?.trim() || document.title,
    show: metaContent('meta[property="og:site_name"]') || metaContent('meta[name="application-name"]'),
    artwork: metaContent('meta[property="og:image"]'),
  });
  const toDataUrl = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsDataURL(blob); });
  const podSend = async (m) => {
    if (m.blob) { const { blob, ...rest } = m; m = { ...rest, dataUrl: await toDataUrl(blob) }; }
    if (!alive()) return retire();
    try { chrome.runtime.sendMessage(m).catch(() => {}); } catch { retire(); }
  };
  const pod = ClipEngine.create({ getVideo: pickAudio, meta: podMeta, send: podSend, audioOnly: true });
  // How this episode can be recorded: 'direct' from the page's player, 'copy' through a second player the
  // audio server allows, or 'tab' by recording the tab's sound. Checked once per episode.
  const routes = new Map();
  function route(a) {
    const src = a.currentSrc || a.src || (a.querySelector('source') || {}).src;
    // Encrypted audio (Spotify and similar services) is protected, so annotated never records it.
    if (a.mediaKeys) return 'protected';
    if (!src || a.readyState < 1) return 'unknown';
    if (routes.has(src)) return routes.get(src);
    let r = 'direct';
    try { const es = a.captureStream(); es.getTracks().forEach((t) => t.stop()); }
    catch (e) { r = /cross-origin/i.test(e.message) ? 'checking' : 'blocked'; }
    routes.set(src, r);
    if (r === 'checking') {
      const c = document.createElement('audio');
      c.crossOrigin = 'anonymous'; c.preload = 'metadata';
      const done = (v) => { if (routes.get(src) === 'checking') routes.set(src, v); c.removeAttribute('src'); };
      c.addEventListener('loadedmetadata', () => done('copy'));
      c.addEventListener('error', () => done('tab'));
      setTimeout(() => done('tab'), 10000);
      c.src = src;
    }
    return r;
  }
  // How much writing is on the page, which is only used to guess whether this looks like a podcast and is
  // read when a panel is first made. Measuring it asks the page for a full layout, and the panel asks for
  // this two and a half times a second, so it is measured now and then rather than every time.
  let textLen = -1, textAt = 0;
  function pageTextLen() {
    const now = Date.now();
    // A page still loading has no words yet, and holding that for ten seconds told YouTube's home page it had
    // none. Nought is measured again every time, and only a page that has finished loading may keep it.
    if (textLen < 1 || now - textAt > 10000) { textLen = (document.body.innerText || '').trim().length; textAt = now; }
    if (textLen < 1 && document.readyState !== 'complete') return -1;
    return textLen;
  }
  function podInfo() {
    const a = pickAudio();
    if (!a) return { ok: false, found: false };
    // Some players only load the episode on play. Ask for its length without starting it.
    if (!isFinite(a.duration) && a.readyState === 0 && a.paused && a.preload === 'none') { a.preload = 'metadata'; try { a.load(); } catch {} }
    const type = metaContent('meta[property="og:type"]').toLowerCase();
    const likely = /podcast|episode|audio|music/.test(type + ' ' + location.pathname.toLowerCase()) || pageTextLen() < 2500;
    return { ...pod.info(), found: true, src: a.currentSrc || a.src || (a.querySelector('source') || {}).src || '', likely, route: route(a) };
  }

  // X opens a profile card when the mouse rests on a name, and a capture takes its picture a moment later,
  // so the card used to land on top of the post in the screenshot. For the few seconds a capture takes,
  // those cards are not drawn. Other sites have nothing it matches.
  let hoverOff = null;
  function hideHovers() {
    let st = document.getElementById('annotated-no-hover');
    if (!st) {
      st = document.createElement('style'); st.id = 'annotated-no-hover';
      st.textContent = '[data-testid="HoverCard"], [data-testid="hoverCardParent"] { display: none !important; }';
      (document.head || document.documentElement).appendChild(st);
    }
    clearTimeout(hoverOff);
    hoverOff = setTimeout(() => { const s = document.getElementById('annotated-no-hover'); if (s) s.remove(); }, 5000);
  }

  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    if (orphaned()) return;
    switch (msg?.type) {
      case 'aping': reply({ ok: true }); return;
      case 'pod-info': reply(podInfo()); return;
      // Where a podcast app's own player is, read from the time it shows, because an app that encrypts its
      // audio lets nothing else be read. Spotify labels it playback-position. Unverified on other apps.
      case 'app-pos': {
        const el = document.querySelector('[data-testid="playback-position"]');
        const t = el ? el.textContent.trim() : '';
        const parts = t.split(':').map(Number);
        const secs = parts.length >= 2 && parts.every((n) => Number.isFinite(n)) ? parts.reduce((a, n) => a * 60 + n, 0) : null;
        reply({ secs }); return;
      }
      case 'clear-captured': ArticleCore.clearHighlights(document); page.forgetTaken(); reply({ ok: true }); return;
      case 'pod-seek': pod.seek(msg.t); reply({ ok: true }); return;
      case 'pod-preview': pod.preview(msg.start, msg.end); reply({ ok: true }); return;
      case 'pod-pause': pod.pause(); reply({ ok: true }); return;
      case 'pod-capture': pod.capture(msg.start, msg.end).then(() => reply({ ok: true })).catch((e) => reply({ ok: false, error: e.message, code: e.code })); return true;
      case 'pod-play-range': pod.playRange(msg.start, msg.end).then(() => reply({ ok: true })).catch((e) => reply({ ok: false, error: e.message })); return true;
      case 'pod-abort': pod.abort(); pod.stopRange(); reply({ ok: true }); return;
      case 'a-info': reply({ ...page.info(), textLen: pageTextLen() }); return;
      case 'capture-passage':
        hideHovers();
        page.capture().then((r) => { const { marks, ...rest } = r; reply({ ...rest, vw: window.innerWidth }); })
          .catch((e) => reply({ ok: false, error: e.message }));
        return true;
      case 'set-exact': page.setExact(msg.exact); reply({ ok: true }); return;
      case 'set-snap': page.setSnap(msg.exact); reply({ ok: true }); return;
      case 'set-pen': penName = msg.pen; if (msg.ink) INK = msg.ink; paint(); reply({ ok: true }); return;
      case 'clear-selection': page.clear(); reply({ ok: true }); return;
      case 'widen-quote': { const t = page.widen(!!msg.peek); reply({ ok: !!t, text: t || '' }); return; }
      case 'pin-and-annotate': page.requestAnnotate(); reply({ ok: true }); return;
      case 'p-info': {
        const r = PostCore.extract(document, location);
        if (!r) { reply({ ok: false, error: 'Waiting for the post to load.' }); return; }
        const { el, ...rest } = r; reply({ ok: true, ...rest }); return;
      }
      // Sent once the screenshot has been taken, so a post folded behind Show more goes back to how it was.
      // The stroke is already on the page by then, drawn before the picture rather than after it.
      case 'fold-restore': { page.refold(); reply({ ok: true }); return; }
      case 'capture-post': {
        hideHovers();
        // A selection inside a reply annotates that reply. Otherwise the page's main post.
        const inPost = page.selectedPost();
        const r = inPost ? PostCore.read(inPost, location) : PostCore.extract(document, location);
        if (!r) { reply({ ok: false, error: 'Could not find the post on this page.' }); return; }
        // Words selected inside the post become its quote. Taking them also clears the highlight before the screenshot.
        const picked = page.takeWithin(r.el);
        if (picked && picked !== r.text) r.quote = picked;
        // A long post is folded behind Show more. Open it so the screenshot holds the whole post.
        page.unfold(r.el);
        // Posts taller than the window (with a video, say) are framed from their top, so the author and text are in the screenshot.
        const tall = r.el.getBoundingClientRect().height > window.innerHeight - 80;
        r.el.scrollIntoView({ block: tall ? 'start' : 'center', behavior: 'instant' });
        if (tall) window.scrollBy(0, -64);
        // The post settles, then the pen crosses the words that were quoted, and the picture waits for it.
        // Drawing it finished for the picture and again afterwards marked the passage twice over.
        // The reply is sent whatever happens in here. Without this, anything that threw left the panel
        // waiting on a reply that was never going to come, sitting on Capturing for good.
        requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(() => {
          let drawing = 0;
          try { drawing = page.paintTaken(); } catch (e) { reply({ ok: false, error: e.message }); return; }
          setTimeout(() => {
            try {
              const b = r.el.getBoundingClientRect();
              const { el, ...rest } = r;
              reply({ ok: true, ...rest, clip: { x: b.left, y: b.top, w: b.width, h: b.height }, vw: window.innerWidth });
            } catch (e) { reply({ ok: false, error: e.message }); }
          }, drawing + 40);
        }, 150)));
        return true;
      }
    }
  });
})();
