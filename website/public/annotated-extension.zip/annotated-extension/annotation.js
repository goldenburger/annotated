// This tab only ever shows annotated's own pages, so a mark left by one of them means there is somewhere
// of ours behind us to go back to. A tab opened straight onto a shared link has no mark and no Back.
const beenHereBefore = (() => { try { const had = sessionStorage.getItem('annSeen'); sessionStorage.setItem('annSeen', '1'); return !!had; } catch { return false; } })();
// Annotation page inside the extension. Shows annotations saved on this computer and shared ones from the
// database. Once an annotation is shared, comments, reactions, votes, edits and claims go to the database.
(async () => {
  Prefs.init(Prefs.chromeBackend());
  let me = null;
  // Pages show the signed-in account's name and photo. Signed out, they fall back to "You".
  // This is read again on every load, because this one tab is reused for every annotation and the account
  // can change in the panel beside it without the page ever reloading. Reading it once meant one person's
  // id travelled with another person's token, which the database refused, and meant Follow appeared on your
  // own annotation and never on anyone else's.
  // Who you are, waited for three seconds at most: with the network online but nothing getting through the client retried
  // for about seven, and even an annotation kept on this computer sat on its outline. A late answer that differs draws again.
  // A failed read (FAILED) is not signing out, and a late answer never redraws over a box in use or an open question.
  const FAILED = Symbol('failed');
  const inUse = () => [...document.querySelectorAll('textarea, input[type="text"]')].some((b) => b.value && b.offsetParent) || !!document.querySelector('.delAllAsk:not([hidden]), dialog[open], .signAsk');
  const readMe = async () => {
    const p = Backend.profile().catch(() => FAILED);
    const got = await Promise.race([p, new Promise((r) => setTimeout(() => r(undefined), 3000))]);
    if (got === undefined) p.then((v) => { if (v === FAILED || (v && v.id) === (me && me.id)) return; me = v; AnnotationPage.setMe(me); lateLoad(loadGen); });
    else if (got !== FAILED) me = got;
    AnnotationPage.setMe(me);
  };
  const page = document.getElementById('page');
  const permalinkOf = (id, author) => Backend.permalink(id, (author && author.handle) || (me && me.handle));
  // Row level security speaks in table names and policies. Nobody reading an annotation should see that, so
  // the real message goes to the console and the person gets a sentence about what to do.
  const notYours = (e) => /row-level security|violates|permission|not yours/i.test((e && e.message) || '');
  // The database's own limits say what happened in plain words, so those are passed on as they are.
  const LIMIT = /lot of comments|lot of annotations|as many reactions|has to be an emoji|lot of claims|can't reply here|can't do that here|can't follow|can't annotate|one level deep|fifteen minutes|nowhere to go/i;
  // The panel beside this page shows the same annotation's reactions, comments and votes, and reads them only
  // when something tells it to look again. A shared annotation's activity lives in the database, not in the
  // copy on this computer, so the page says so each time.
  const nudgePanel = () => { try { chrome.storage.local.set({ annotatedStamp: Date.now() }); } catch { /* not in the extension */ } };
  const sayProblem = (e) => {
    console.warn('annotated', e);
    if (LIMIT.test((e && e.message) || '')) { alert(e.message); return; }
    alert(notYours(e) ? 'That did not save, because it is not yours to change. Sign in again from the panel and try once more.'
                      : 'That did not save. Check your connection and try again in a moment.');
  };

  let loadGen = 0, movedHere = false, arrived = null;
  // A late answer (who you are, the rail) draws the page again, but not over a plane still arriving from Publish, a box
  // in use or an open question, and not by scrolling the reader back to the top (twelfth audit pass); it waits instead.
  const lateLoad = (gen, tries = 0) => {
    if (gen !== loadGen || tries > 20) return;
    if (inUse() || document.querySelector('.pl-landing, .pl-arriving, body > .pl-layer')) { setTimeout(() => lateLoad(gen, tries + 1), 1500); return; }
    load({ late: true });
  };
  const load = async ({ late = false } = {}) => {
    const my = ++loadGen;
    // Who you are and the local copy are asked for together, and the rest below too, since one after another they
    // left the page white for most of a second before the plane from Publish arrived (recording of 2026-09-25 at
    // 15:38, 1:02).
    const meP = readMe();
    const id = decodeURIComponent(location.hash.slice(1));
    const localP = id ? Store.get(id).catch(() => null) : Promise.resolve(null);
    // How you got here decides what Back can honestly mean. The panel says so when it sent you here from
    // publishing. Otherwise anything behind you in this tab is one of our own pages, because this tab only
    // ever shows them. Arriving cold on a shared link there is nothing behind you at all.
    let from = 'cold';
    // Drawn again for the same annotation (after signing in, Try again), it keeps how you arrived; the first load took
    // the mark, and Back to the post went (ninth audit pass).
    if (arrived && arrived.id === id) from = arrived.from;
    else {
      try {
        const o = await chrome.storage.session.get('annFrom');
        if (o && o.annFrom === 'publish') from = 'publish';
        await chrome.storage.session.remove('annFrom');
      } catch { /* no session storage, so treat it as any other arrival */ }
      if (from !== 'publish' && (beenHereBefore || movedHere)) from = 'history';
      arrived = { id, from };
    }
    const local = await localP;
    await meP;
    if (!late) window.scrollTo(0, 0);
    // Saved on this computer, or shared by anyone.
    let rec = local ? { id, ...local } : null;
    let shared = !!(local && local.cloud);
    let failed = false;
    if (!rec && id) { rec = await Cloud.get(id).catch(() => { failed = true; return null; }); shared = !!rec; }
    if (my !== loadGen) return;
    if (!rec && failed) {
      page.className = '';
      document.title = 'Did not load | annotated';
      AnnotationPage.renderMissing(page, { title: 'This did not load', why: 'Check your connection and try again.', siteNav: false, onHome: () => { location.href = 'feed.html'; } });
      const home = page.querySelector('.shellEmpty .missHome');
      const b = document.createElement('button'); b.type = 'button'; b.className = 'ghost sm'; b.textContent = 'Try again';
      b.addEventListener('click', () => { if (b.disabled) return; b.disabled = true; load(); });
      if (home) { home.parentElement.insertBefore(b, home); home.parentElement.insertBefore(document.createTextNode(' '), home); } else page.appendChild(b);
      return;
    }
    if (!rec) {
      const gone = Store.wasDeleted && Store.wasDeleted(id);
      page.className = '';
      document.title = 'annotated';
      AnnotationPage.renderMissing(page, {
        title: gone ? 'This annotation was deleted' : 'This annotation was not found',
        why: gone ? 'It was taken down, so there is nothing left to show.' : 'The link may be wrong, or it was deleted before this computer saw it.',
        siteNav: false, onHome: () => { location.href = 'feed.html'; },
      });
      return;
    }
    if (Cloud.markOpened) Cloud.markOpened(id);
    let author = rec.author || (shared && local && local.author) || null;
    // Publishing takes a copy of the author, and the local copy is preferred over the shared one because it
    // holds the files. That copy goes stale the moment a name or a handle changes, so a shared annotation
    // asks who its author is now and keeps the answer.
    const socialP = shared ? Cloud.social(id, me && me.id).catch(() => null) : Promise.resolve(null);
    const recordsP = Store.allMeta().catch(() => []);
    // Your pin and your mutes and blocks, for the menu (migration 28).
    const pinP = shared && me ? Cloud.pinnedOf(me.id).catch(() => null) : Promise.resolve(null);
    const blocksP = shared && me ? Cloud.blocks(me.id).catch(() => new Map()) : Promise.resolve(new Map());
    const discoveryP = Cloud.discovery(me, {
      signIn: (p) => Backend.signIn(p).then(() => load()).catch(() => {}),
      onPerson: (handle) => Backend.client.from('profiles').select('id').eq('handle', handle).maybeSingle().then(({ data }) => { if (data) location.href = 'feed.html#user=' + encodeURIComponent(data.id); }),
    }).catch(() => null);
    if (shared && author && author.id) {
      const now = await Cloud.authorNow(author.id).catch(() => null);
      if (now && (now.handle !== author.handle || now.name !== author.name || now.avatar !== author.avatar)) {
        author = now;
        if (local) Store.update(id, { author: now }).catch(() => {});
      }
    }
    // A plain yes or no. Signed out this used to come out as null, which the banner took for yes, so everyone
    // else's annotation said Published.
    const mine = !author || !!(me && author.id === me.id);
    const title = AnnotationPage.titleOf(rec.item);
    document.title = `${rec.take.text || title} | annotated`;

    // Shared: everyone's comments, reactions and votes come from the database.
    let comments = rec.comments || [], reactions = rec.reactions || [];
    if (shared) {
      const soc = await socialP;
      if (soc) {
        comments = soc.comments; reactions = soc.reactions;
        if (rec.take.poll) rec.take = { ...rec.take, poll: { ...rec.take.poll, counts: soc.poll.counts, vote: soc.poll.vote } };
      }
    }
    // Your card counts what you have published, not only the copies kept on this computer: published from another
    // computer, or with its copy gone, an annotation was not counted and the card said 0 (2026-09-30). Two seconds at most.
    const publishedP = me && typeof Cloud !== 'undefined' && Cloud.countBy
      ? Promise.race([Cloud.countBy(me.id).catch(() => 0), new Promise((r) => setTimeout(() => r(0), 2000))]) : Promise.resolve(0);
    const records = await recordsP;
    // Following and discovery for the rail and the author's Follow button.
    // Three seconds at most: with the network failing and the token expired, every request first retried a refresh for up
    // to half a minute, and the annotation, even one kept on this computer, waited on its rail (ninth audit pass).
    const soc = await Promise.race([discoveryP, new Promise((r) => setTimeout(() => r(null), 3000))]);
    // Arriving late, the rail is drawn then (Follow, your card), unless a box is in use.
    if (!soc) discoveryP.then((s) => { if (s) lateLoad(my); });
    // Drawn at once with the copies here; the published count corrects the card when it comes (waiting for it held the
    // page by up to two seconds, which walk1538 caught).
    const yourCount = AnnotationPage.mineCount(records, me && me.id);
    publishedP.then((n) => {
      n = Number(n) || 0;
      if (n <= yourCount) return;
      const apply = (tries) => {
        const st = document.querySelector('.rail .railcard .who .stats');
        if (!st) { if (tries < 10) setTimeout(() => apply(tries + 1), 300); return; }
        st.textContent = st.textContent.replace(/^\d+ annotations?/, n + (n === 1 ? ' annotation' : ' annotations'));
        if (AnnotationPage.setYours) AnnotationPage.setYours({ mine: n });
      };
      apply(0);
    });
    const social = soc ? { ...soc, youId: me && me.id, followsAuthor: !!(author && soc.followed.has(author.id)),
      you: me && soc.youCounts ? { id: me.id, annotations: yourCount, ...soc.youCounts } : null } : null;
    // Signed out, shared annotations can be read but not commented on or reacted to.
    const [pinnedId, blockMap] = await Promise.all([pinP, blocksP]);
    const needSignIn = () => { if (shared && !me) { AnnotationPage.signInPrompt({ text: 'Sign in to comment, react or vote.', onSignIn: (p) => Backend.signIn(p).then(() => load()).catch(() => {}) }); return true; } return false; };

    // Everything is here, so the skeleton comes down and the page goes up in the same breath.
    if (my !== loadGen) return;
    page.className = '';
    await AnnotationPage.render(page, {
      id, item: rec.item, take: rec.take, created: rec.created,
      edited: rec.edited || null, quoteOf: rec.quoteOf || null, quoted: rec.quoted || null,
      pinned: !!(mine && pinnedId && pinnedId === id), blockKind: !mine && author ? blockMap.get(author.id) || null : null,
      author: mine ? null : author, mine,
      permalink: permalinkOf(id, author),
      backIsSource: from === 'publish',
      backLabel: from === 'publish'
        ? rec.item.site === 'x' ? 'Back to the post' : ({ video: 'Back to the video', post: 'Back to the post', audio: 'Back to the episode' }[rec.item.kind] || 'Back to the article')
        : 'Back',
      // Only arriving from Publish. Opened later from a list or trending, it used to say Published again.
      showBanner: mine && from === 'publish' && !(local && local.seen),
      // Kept only on this computer: no link to share yet.
      localOnly: !shared && !!local,
      youId: me && me.id,
      stats: { annotations: yourCount, followers: (soc && soc.youCounts && soc.youCounts.followers) || 0 },
      comments, reactions, records, social,
      // The panel beside this page already carries Home and your profile.
      siteNav: false,
    }, {
      onBack: from === 'cold' ? null : from === 'publish' ? async () => {
        const ok = local && local.sourceTabId ? await chrome.tabs.update(local.sourceTabId, { active: true }).then(() => true).catch(() => false) : false;
        // The tab it was captured from is gone, so the source opens in one of its own. Sending this tab there
        // would take the annotation with it, and this is the only tab annotated keeps.
        const src = String(AnnotationPage.srcUrlOf(rec.item) || '');
        if (!ok && /^https?:\/\//i.test(src)) chrome.tabs.create({ url: src });
      } : () => history.back(),
      onHome: () => { location.href = 'feed.html'; },
      onProfile: () => { location.href = mine ? 'feed.html#profile' : 'feed.html#user=' + encodeURIComponent(author.id); },
      onTag: (tag) => { location.href = 'feed.html#tag=' + encodeURIComponent(tag); },
      onYou: () => { location.href = 'feed.html#profile'; },
      onOpen: (oid) => { location.hash = encodeURIComponent(oid); },
      onDismissBanner: () => local && Store.update(id, { seen: true }),
      onComments: async (list, change = {}) => {
        if (!shared) return Store.update(id, { comments: list });
        // False when nothing was saved, and the page takes the change back (ninth audit pass).
        if (change.restored) return true;   // Undo of a delete that never left this page
        if (needSignIn()) return false;
        try {
          if (change.added) { change.added.adding = Cloud.addComment(id, me.id, change.added.text, change.added.gif, change.added.upload, change.added.parentDb); change.added.dbId = await change.added.adding; }
          // Gone already (its annotation was deleted meanwhile, taking it along) is deleted.
          if (change.removed) { if (change.removed.adding) await change.removed.adding.catch(() => {}); if (change.removed.dbId) await Cloud.deleteComment(change.removed.dbId).catch((e) => { if (!/not yours to delete/i.test((e && e.message) || '')) throw e; }); }
          if (change.reaction && change.comment && change.comment.dbId) await Cloud.reactComment(change.comment.dbId, me.id, change.reaction.emoji, change.reaction.on);
          nudgePanel();
          return true;
        } catch (e) { sayProblem(e); return false; }
      },
      onReactions: async (list, change) => {
        if (!shared) return Store.update(id, { reactions: list });
        if (!change) return;
        if (needSignIn()) return false;
        try { await Cloud.react(id, me.id, change.emoji, change.on); nudgePanel(); return true; } catch (e) { sayProblem(e); return false; }
      },
      onPollVote: async (vote) => {
        if (!shared) return Store.update(id, { take: { ...rec.take } });
        if (needSignIn()) return false;
        try { await Cloud.vote(id, me.id, vote); nudgePanel(); return true; } catch (e) { sayProblem(e); return false; }
      },
      onClaim: shared ? (data) => Cloud.claim(id, data).then((r) => { if (r.error) throw r.error; }) : null,
      // Saved here but not shared (signed out at the time, or the upload failed): share it now. Signed out,
      // this page signs you in itself. It used to send you to the panel to do that.
      shareNeedsSignIn: !me,
      onShareNow: !shared && local ? async (provider) => {
        if (!me) {
          try { await Backend.signIn(provider); } catch { /* cancelled, or the window was closed */ }
          me = await Backend.profile().catch(() => null);
          if (!me) throw new Error('Sign-in did not finish, so it is still only on this computer.');
        }
        const author = await Cloud.publish(id, local.item, local.take);
        if (!author) throw new Error('Sign-in did not finish, so it is still only on this computer.');
        await Store.update(id, { cloud: true, author });
        // Comments and reactions made while it was only on this computer come along.
        await Cloud.carryOver(id, author.id, local.comments || [], local.reactions || []).catch((e) => { console.warn('carryOver', e); alert('The annotation is shared, but its earlier comments did not come across with it.'); });
        load();
      } : null,
      // Annotate this: your take on it, published as your own annotation that answers it, then opened.
      quoteNeedsSignIn: () => { if (me) return false; AnnotationPage.signInPrompt({ text: 'Sign in to annotate this.', onSignIn: (p) => Backend.signIn(p).then(() => load()).catch(() => {}) }); return true; },
      onQuote: shared ? async (take) => {
        if (!me) { AnnotationPage.signInPrompt({ text: 'Sign in to annotate this.', onSignIn: (p) => Backend.signIn(p).then(() => load()).catch(() => {}) }); throw new Error('Sign in first, then publish.'); }
        const r = await Cloud.quote({ id, item: rec.item }, take);
        if (!r) throw new Error('Sign in first, then publish.');
        nudgePanel();
        location.hash = encodeURIComponent(r.id);
      } : null,
      onBlock: shared && !mine && me && author ? async (kind) => { try { await Cloud.setBlock(me.id, author.id, kind); nudgePanel(); return true; } catch (e) { console.warn('annotated', e); return false; } } : null,
      ...(mine ? {
        onPin: shared && me ? async (on) => { try { await Cloud.pin(me.id, on ? id : null); nudgePanel(); return true; } catch (e) { console.warn('annotated', e); return false; } } : null,
        onDelete: async () => {
          if (shared && me) await Cloud.remove(id, me.id).catch((e) => { console.warn('remove', e); alert(notYours(e) ? 'That is not yours to delete, so nothing was removed.' : 'It could not be deleted online, so it was kept. Try again in a moment.'); throw e; });
          await Store.del(id).catch(() => {});
          location.href = 'feed.html#profile';
        },
        onEdit: async ({ text, tag }) => {
          // Online first, so a refused edit leaves this computer's copy as it was too.
          if (shared) { try { await Cloud.edit(id, { text, tag }); } catch (e) { sayProblem(e); throw e; } }
          if (local) await Store.update(id, { take: { ...local.take, text, tag } });
          document.title = `${text || title} | annotated`;
        },
      } : {}),
    });
    // The banner is for the first visit only.
    if (local && !local.seen) Store.update(id, { seen: true });
  };
  window.addEventListener('hashchange', () => { movedHere = true; load(); });
  // Signing in or out in the panel changes what this page may offer, and the page does not reload by itself.
  Backend.onChange((who) => { if ((who && who.id) !== (me && me.id)) load(); });
  load();
})();
